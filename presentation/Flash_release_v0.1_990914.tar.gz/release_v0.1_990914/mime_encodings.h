{ "Z", "x-compress" },
{ "gz", "x-gzip" },
{ "uu", "x-uuencode" },
