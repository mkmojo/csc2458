#ifndef _VERSION_H_
#define _VERSION_H_

#define SERVER_SOFTWARE "Flash v0.1a Sep 14 99"
#define SERVER_ADDRESS "http://www.cs.rice.edu/~vivek/"

#endif /* _VERSION_H_ */
